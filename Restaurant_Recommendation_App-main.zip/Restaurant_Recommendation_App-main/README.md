# Restaurant_Recommendation_App

This is a Simple project that my team and I have developed for our System Integration Subject
The purpose of this project is to practice the use API in our program.

The user would input a name of a restaurant
The API would request and retrive the data of the said restaurant
The program would then organize it from highest rating and what is close to the users location.

Languages we used:
Python,
HTML,
CSS

API:
Yelp,
Zomato
